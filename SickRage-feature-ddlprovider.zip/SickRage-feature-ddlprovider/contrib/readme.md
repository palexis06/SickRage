SickRage Contrib
=====
Stuff contributed to SickRage, or included of users leisure

## What will you find in here?
 - Scripts
 - Links to other repositories we think make your life better
 - Custom themes
 - Other things that may come in handy

