### Before submitting your issue:

Enable debug logging in SickRage settings, reproduce the error (be sure to disable after the bug is fixed)

Branch/Commit:
OS:
What you did:
What happened:
What you expected:
Logs:
```
PASTE LOGS HERE
```
